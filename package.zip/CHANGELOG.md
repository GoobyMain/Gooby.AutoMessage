0.2.6
- updated for integrated mod settings

0.2.3
- bugfix

0.2.2
- added support for round-based modes and "good half" message option