# Gooby.AutoMessage

An edited version of cat_or_not's AutoGG mod, default settings maintain the same functionality as that mod

Use the Mod Settings mod menu to change the message contents and the delay before auto sending messages

Please report any bugs/crashes/etc. at https://github.com/GoobyMain/Gooby.AutoMessage/issues or message QuestinHowl#9824 on discord
